<?php $__env->startSection('title', 'Approve Pengajuan Pinjaman Karyawan'); ?>
<?php $__env->startSection('page-title', 'Approve Pengajuan Pinjaman Karyawan'); ?>


<?php $__env->startSection('vendor-style'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/datatables.min.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/animate/animate.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/sweetalert2.min.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/pickadate/pickadate.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/zebra_datepicker@latest/dist/css/bootstrap/zebra_datepicker.min.css">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset(mix('css/pages/data-list-view.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('css/plugins/extensions/toastr.css'))); ?>">

  <style>

    .invalid-tooltip{
      right:0;
      margin-right: 15px;
    }

    table.data-list-view.dataTable, table.data-thumb-view.dataTable{
      border-spacing: 0 !important;
      padding: 0.5rem 0.7rem !important;
    }

  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  <section id="data-list-view" class="data-list-view-header card" style="padding:25px 15px;">

    
    <div class="table-responsive">
      <table class="table data-list-view" style="border:none;width:100%">
        <thead>
        <tr>
          <th width="45px">No.</th>
          <th>Kode</th>
          <th>Karyawan</th>
          <th>Akun Kas</th>
          <th>Keterangan</th>
          <th>Tanggal</th>
          <th>Nominal (Rp. )</th>
          <th>Waktu Input</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
        </thead>
      </table>
    </div>
    
    

    
    <div class="modal fade text-left" id="modal2" tabindex="-1" role="dialog"
         aria-labelledby="myModalLabel2" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-sm" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title" id="myModalLabel2">Proses Approve Peminjaman</h4>
            <button type="button" class="close" data-dismiss="modal" id="btntutup2" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">

            <div class="row">
              <input type="hidden" name="idpengajuan" id="idpengajuan" />
              <div class="col-sm-12 mb-1 data-field-col">
                <label for="akun">Akun Pemberian Pinjaman</label>
                <select class="form-control select" name="akun" id="akun">
                  <option value="" data-foo="" selected disabled> Pilih Akun Pinjaman </option>
                  <?php $__currentLoopData = $akunskas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option data-foo="<?php echo e($akun->kategori); ?>" value="<?php echo e($akun->kode_akun); ?>"><?php echo e($akun->kode_akun); ?> - <?php echo e($akun->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-sm-12 mb-1 data-field-col">
                <label for="nominalapprove">Nominal yang Disetujui</label>
                <input type="text" class="form-control" name="nominalapprove" id="nominalapprove" value="0" onfocus="f_tonumber(this.id)" onblur="f_tocurrency(this.id);" required>
              </div>

              <div class="col-sm-12 text-right mt-2 mb-1 pr-3">
                <button type="button" class="btn btn-primary" value="Simpan" id="btnsubmit" name="btnsubmit" onclick="f_simpanakun(this.value)">Submit</button>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>

  </section>
  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
  
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.bootstrap4.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/buttons.bootstrap.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/extensions/sweetalert2.all.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/extensions/toastr.min.js'))); ?>"></script>
  <script src="https://momentjs.com/downloads/moment-with-locales.min.js"></script>
  <script src="http://cdn.datatables.net/plug-ins/1.10.15/dataRender/datetime.js"></script>
  <script src="https://unpkg.com/accounting@0.4.1/accounting.js"></script>
  <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.date.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/legacy.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/forms/select/select2.full.min.js'))); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/zebra_datepicker@1.9.13/dist/zebra_datepicker.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
  

  <script>
    $(document).ready(function() {

      "use strict"

      $("body").tooltip({ selector: '[data-toggle=tooltip]' });

      // init list view datatable
      f_loadtable();

      $(".select").select2({
        dropdownAutoWidth: true,
        width: '100%',
        matcher: matchCustom,
        templateResult: formatCustom
      });

      f_loadtable();

    });

    function stringMatch(term, candidate) {
      return candidate && candidate.toLowerCase().indexOf(term.toLowerCase()) >= 0;
    }

    function matchCustom(params, data) {
      // If there are no search terms, return all of the data
      if ($.trim(params.term) === '') {
        return data;
      }
      // Do not display the item if there is no 'text' property
      if (typeof data.text === 'undefined') {
        return null;
      }
      // Match text of option
      if (stringMatch(params.term, data.text)) {
        return data;
      }
      // Match attribute "data-foo" of option
      if (stringMatch(params.term, $(data.element).attr('data-foo'))) {
        return data;
      }
      // Return `null` if the term should not be displayed
      return null;
    }

    function formatCustom(state) {
      return $(
        '<div><div>' + state.text + '</div><div class="foo">'
        + $(state.element).attr('data-foo')
        + '</div></div>'
      );
    }

    function minmax(value, min, max)
    {
      if(parseInt(value) < min || isNaN(parseInt(value)))
        return min;
      else if(parseInt(value) > max)
        return max;
      else return value;
    }

    function f_tonumber(param){
      let value = $("#"+param).val();
      $("#"+param).val(accounting.unformat(value , ','));
    }

    function f_tocurrency(param){
      let value = $("#"+param).val();
      $("#"+param).val(accounting.formatNumber(value, 0, ".", ","));
    }

    function f_loadtable(){
      let tanggal = $("#tanggalfilter").val();

      $("#tabel").removeClass('hidden');

      let dataListView = $(".data-list-view").DataTable({
        "destroy": true,
        processing: true,
        serverSide: true,
        ajax: "/pinjaman-karyawan/approve-pengajuan/list?tanggal="+tanggal,
        columns: [
          {data: 'DT_RowIndex', name: 'DT_RowIndex', searchable: false},
          {data: 'kode', name: 'kode'},
          {data: 'namakaryawan', name: 'namakaryawan'},
          {data: 'kolomakunkas', name: 'kolomakunkas'},
          {data: 'keterangan', name: 'keterangan'},
          {data: 'tanggal', name: 'tanggal',render: function ( data, type, row, meta ) {
              if(data != null){
                return moment(data).locale('id').format('DD MMMM YYYY');
              }else{
                return '-';
              }
          }},
          {data: 'nominal', name: 'nominal', render: $.fn.dataTable.render.number( '.', ',', 2, 'Rp ' )},
          {data: 'created_at', name: 'created_at',render: function ( data, type, row, meta ) {
              if(data != null){
                  return moment(data).locale('id').format('DD MMMM YYYY HH:mm:ss');
              }else{
                  return '-';
              }
          }},
          {data: 'status', name: 'status'},
          {data: 'action', name: 'action', orderable: false, searchable: false}
        ],
        responsive: false,
        columnDefs: [
          {
            orderable: true,
          }
        ],
        dom:
          '<"top"<"actions action-btns"B><"action-filters"lf>><"clear">rt<"bottom"<"actions">p>',
        oLanguage: {
          sLengthMenu: "_MENU_",
          sSearch: ""
        },
        aLengthMenu: [[10, 20, 50, -1], [10, 20, 50, 'All']],
        order: [[0, "asc"]],
        bInfo: false,
        pageLength: 10,
        buttons: [
          {

          }
        ],
        initComplete: function (settings, json) {
          $(".dt-buttons .btn").removeClass("btn-secondary")
        }
      });
    }

    function f_prosesapprove(param,akun,nominal){
        $("#modal2").modal();
        $("#idpengajuan").val(param);
        $("#akun").val(akun).trigger('change');
        $("#nominalapprove").val(accounting.formatNumber(nominal, 0, ".", ","));
    }


    function f_delete(param) {
        Swal.fire({
            title: 'Konfirmasi',
            text: "Apakah anda yakin untuk menolak data ini?",
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya',
            cancelButtonText: 'Tidak',
            confirmButtonClass: 'btn btn-primary',
            cancelButtonClass: 'btn btn-danger ml-1',
            buttonsStyling: false,
        }).then(function (result) {
            if (result.value) {
                let link = "/pinjaman-karyawan/approve-pengajuan/tolak"; // Link untuk hapus

                $.post(link, {idpengajuan: param, _token: '<?php echo e(csrf_token()); ?>'})
                    .done(function (data) {
                        if (data == "berhasil") {
                            toastr.success('Data ini berhasil ditolak.', 'Berhasil', {
                                positionClass: 'toast-top-right',
                                containerId: 'toast-top-right',
                                "closeButton": true
                            });
                            f_loadtable();
                        }
                    });
            }
        })
    }
    
    function f_simpanakun(param){
        let link = "/pinjaman-karyawan/approve-pengajuan/approve"; // Link default untuk simpan
        let akun = $("#akun").val();
        let idpengajuan = $("#idpengajuan").val();
        let nominal = accounting.unformat($("#nominalapprove").val() , ',');

        if(akun == null || nominal == 0){
            alert('Pilih akun dan input peminjaman terlebih dahulu!');
            return;
        }

        $.post(link,{akun: akun, idpengajuan: idpengajuan, nominal: nominal, _token: '<?php echo e(csrf_token()); ?>'})
            .done(function(data){
                toastr.success('Data berhasil terlunaskan.', 'Berhasil', { positionClass: 'toast-top-right', containerId: 'toast-top-right', "closeButton": true });
                f_loadtable();
                $("#btntutup2").click();
                $("#akun").val('').trigger('change');
                $("#nominalapprove").val("0");
                $("#idpengajuan").val("");
            });

    }

  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/MJA/resources/views/apps/pinjaman-karyawan/approve-pengajuan/index.blade.php ENDPATH**/ ?>