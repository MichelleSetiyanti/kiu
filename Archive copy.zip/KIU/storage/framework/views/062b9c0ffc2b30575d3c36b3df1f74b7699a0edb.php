<?php
use Illuminate\Support\Facades\Crypt;
?>



<?php $__env->startSection('title', 'View Detil Data Payroll Bulk Detil'); ?>
<?php $__env->startSection('page-title', 'View Detil Data Payroll Bulk Detil'); ?>


<?php $__env->startSection('vendor-style'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/datatables.min.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/animate/animate.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/sweetalert2.min.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/pickadate/pickadate.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset(mix('css/pages/data-list-view.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('css/plugins/extensions/toastr.css'))); ?>">

  <style>

    .invalid-tooltip{
      right:0;
      margin-right: 15px;
    }

  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- card actions section start -->
  <section>
    <!-- Info table about action starts -->
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <h4 class="card-title">Data Payroll</h4>
            <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
            <div class="heading-elements">
              <ul class="list-inline mb-0">
                <li><a data-action="collapse"><i class="feather icon-chevron-down"></i></a></li>
              </ul>
            </div>
          </div>
          <div class="card-content collapse show">
            <div class="card-body">
              <div class="row">
                <div class="col-sm-12">

                  <div class="row mb-1">

                    <div class="col-sm-12 col-md-12 mb-1">

                      <div class="row">

                        <div class="col-sm-12 col-md-6 mb-1">
                          <label>Kode Payroll</label>
                          <input type="text" class="form-control" value="<?php echo e($payroll->kode); ?>" readonly>
                        </div>

                        <div class="col-sm-12 col-md-6 mb-1">
                          <label>Tanggal Pembayaran Gaji</label>
                          <input type="text" class="form-control" value="<?php echo e(Carbon\Carbon::createFromFormat('Y-m-d', $payroll->tanggal_gaji)->isoFormat('D MMMM Y')); ?>" readonly>
                        </div>

                        <div class="col-sm-12 col-md-6 mb-1">
                          <label>Tanggal Mulai Ambil Data Gaji</label>
                          <input type="text" class="form-control" value="<?php echo e(Carbon\Carbon::createFromFormat('Y-m-d', $payroll->tanggal_mulai)->isoFormat('D MMMM Y')); ?>" readonly>
                        </div>

                        <div class="col-sm-12 col-md-6 mb-1">
                          <label>Tanggal Akhir Ambil Data Gaji</label>
                          <input type="text" class="form-control" value="<?php echo e(Carbon\Carbon::createFromFormat('Y-m-d', $payroll->tanggal_selesai)->isoFormat('D MMMM Y')); ?>" readonly>
                        </div>

                        <div class="col-sm-12 col-md-6 mb-1">
                          <label>Jenis Gaji</label>
                          <input type="text" class="form-control" value="<?php echo e($payroll->jenis_gaji); ?>" readonly>
                        </div>

                        <div class="col-sm-12 col-md-6 mb-1">
                          <label>Status Gaji</label>
                          <input type="text" class="form-control" value="<?php echo e($payroll->status); ?>" readonly>
                        </div>

                      </div>


                    </div>

                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Info table about action Ends -->
  </section>

  
  <section id="data-list-view" class="data-list-view-header card" style="padding:25px 15px;">

    
    <div class="table-responsive">
      <table class="table data-list-view" style="border:none;">
        <thead>
        <tr>
          <th width="25px">No.</th>
          <th>Nama Karyawan</th>
          <th>Ak. Pembayaran</th>
          <th>Gaji Awal</th>
          <th>Pot. Absen</th>
          <th>Pot. Terlambat</th>
          <th>Pot. Pulang Awal</th>
          <th>Pot. Pinjaman</th>
          <th>Pot. Lainnya</th>
          <th>Gaji Bersih</th>
          <th>Action</th>
        </tr>
        </thead>
        <tfoot>
        <tr>
          <th colspan="10" style="font-size:18px;text-align:right;"></th>
          <th style="font-size:18px;"></th>
        </tr>
        </tfoot>
      </table>
    </div>
    

    <div class="col-md-12 mt-1">

      <div class="row mr-1">

        <div class="col-md-6 mt-1 offset-3 col-sm-12 text-right"> <h4 style="margin:6px auto;"> Total Gaji : </h4> </div>
        <div class="col-md-3 mt-1 col-sm-12">
          <input type="text" class="form-control" style="font-weight: bold;" name="subtotal" id="subtotal" value="Rp 0" readonly>
        </div>

        <div class="col-md-6 mt-1 offset-3 col-sm-12 text-right"> <h4 style="margin:6px auto;"> Potongan : </h4> </div>
        <div class="col-md-3 mt-1 col-sm-12">
          <input type="text" class="form-control" style="font-weight: bold;" name="totalpotongan" id="totalpotongan" value="0" onfocus="f_tonumber(this.id)" onblur="f_tocurrency(this.id);f_hitungtotal();" readonly>
        </div>

        <div class="col-md-6 mt-1 offset-3 col-sm-12 text-right"> <h4 style="margin:6px auto;"> Total Akhir : </h4> </div>
        <div class="col-md-3 mt-1 col-sm-12">
          <input type="text" class="form-control" style="font-weight: bold;" name="totalakhir" id="totalakhir" value="Rp 0" readonly>
        </div>

        <div class="col-md-12 mt-1 col-sm-12 text-right">
          <button type="button" id="btnsimpan" name="btnsimpan" class="btn bg-gradient-info waves-effect waves-light mr-2" onclick="f_prosesdata('belum selesai')"> Tutup Detil </button>
        </div>

      </div>

    </div>

  </section>
  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
  
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.bootstrap4.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/buttons.bootstrap.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/extensions/sweetalert2.all.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/extensions/toastr.min.js'))); ?>"></script>
  <script src="https://momentjs.com/downloads/moment-with-locales.min.js"></script>
  <script src="http://cdn.datatables.net/plug-ins/1.10.15/dataRender/datetime.js"></script>
  <script src="https://unpkg.com/accounting@0.4.1/accounting.js"></script>
  <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.date.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/legacy.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/forms/select/select2.full.min.js'))); ?>"></script>
  <script src="https://unpkg.com/accounting@0.4.1/accounting.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
  

  <script>

    let idpayroll = "<?php echo e($payroll->id); ?>";

    let idencrypt = "<?php echo e(Crypt::encrypt($payroll->id)); ?>";

    let tanggalmulai = "<?php echo e($payroll->tanggal_mulai); ?>";
    let tanggalselesai = "<?php echo e($payroll->tanggal_selesai); ?>";
    let jenisgaji = "<?php echo e($payroll->jenis_gaji); ?>";

    let selisih = 0;

    $(document).ready(function() {

      "use strict"

      $("body").tooltip({ selector: '[data-toggle=tooltip]' });
      $('#biayatambahan').val(accounting.formatNumber(<?php echo e($payroll->subtotal); ?>, 0, ".", ","));

      // init list view datatable
      f_loadtable();
      f_hitungtotal();
      f_clear();

      $( '.date' ).pickadate({
        formatSubmit: 'yyyy-mm-dd',
        monthsFull: [ 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember' ],
        monthsShort: [ 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des' ],
        weekdaysShort: [ 'Mgg', 'Sn', 'Sl', 'Rb', 'Kms', 'Jum', 'Sab' ],
        today: 'Hari Ini',
        clear: 'Hapus Tanggal',
        close: 'Tutup',
        selectYears: true,
        selectMonths: true,
        firstDay: 1
      });

      $(".select").select2({
        dropdownAutoWidth: true,
        width: '100%',
        matcher: matchCustom,
        templateResult: formatCustom
      });

    });

    function stringMatch(term, candidate) {
      return candidate && candidate.toLowerCase().indexOf(term.toLowerCase()) >= 0;
    }

    function matchCustom(params, data) {
      // If there are no search terms, return all of the data
      if ($.trim(params.term) === '') {
        return data;
      }
      // Do not display the item if there is no 'text' property
      if (typeof data.text === 'undefined') {
        return null;
      }
      // Match text of option
      if (stringMatch(params.term, data.text)) {
        return data;
      }
      // Match attribute "data-foo" of option
      if (stringMatch(params.term, $(data.element).attr('data-foo'))) {
        return data;
      }
      // Return `null` if the term should not be displayed
      return null;
    }

    function formatCustom(state) {
      return $(
        '<div><div>' + state.text + '</div><div class="foo">'
        + $(state.element).attr('data-foo')
        + '</div></div>'
      );
    }

    function f_loadtable(){
      let dataListView = $(".data-list-view").DataTable({
        "destroy": true,
        processing: true,
        serverSide: true,
        ajax: "/payroll/bulk-payroll/list-detil-print?id="+idpayroll,
        columns: [
          {data: 'DT_RowIndex', name: 'DT_RowIndex', searchable: false},
          {data: 'namakaryawan', name: 'namakaryawan'},
          {data: 'namaakun', name: 'namaakun'},
          {data: 'gaji_awal', name: 'gaji_awal', render: $.fn.dataTable.render.number( '.', ',', 0 )},
          {data: 'pot_absen', name: 'pot_absen', render: $.fn.dataTable.render.number( '.', ',', 0 )},
          {data: 'pot_terlambat', name: 'pot_terlambat', render: $.fn.dataTable.render.number( '.', ',', 0 )},
          {data: 'pot_pulangawal', name: 'pot_pulangawal', render: $.fn.dataTable.render.number( '.', ',', 0 )},
          {data: 'pot_pinjaman', name: 'pot_pinjaman', render: $.fn.dataTable.render.number( '.', ',', 0 )},
          {data: 'pot_lainnya', name: 'pot_lainnya', render: $.fn.dataTable.render.number( '.', ',', 0 )},
          {data: 'gaji_bersih', name: 'gaji_bersih', render: $.fn.dataTable.render.number( '.', ',', 0 )},
          {data: 'action', name: 'action', orderable: false, searchable: false}
        ],
        responsive: false,
        columnDefs: [
          {
            orderable: true,
          }
        ],
        dom:
          '<"top"<"actions action-btns"B><"action-filters"lf>><"clear">rt<"bottom"<"actions">p>',
        oLanguage: {
          sLengthMenu: "_MENU_",
          sSearch: ""
        },
        aLengthMenu: [[10, 20, 50, -1], [10, 20, 50, 'All']],
        order: [[0, "asc"]],
        bInfo: false,
        "paging": false,
        "bLengthChange": false,
        pageLength: -1,
        buttons: [
          {

          }
        ],
        initComplete: function (settings, json) {
          $(".dt-buttons .btn").removeClass("btn-secondary")
        }
      });
    }

    function minmax(value, min, max)
    {
      if(parseInt(value) < min || isNaN(parseInt(value)))
        return min;
      else if(parseInt(value) > max)
        return max;
      else return value;
    }

    function f_tonumber(param){
      let value = $("#"+param).val();
      $("#"+param).val(accounting.unformat(value , ','));
    }

    function f_tocurrency(param){
      let value = $("#"+param).val();
      $("#"+param).val(accounting.formatNumber(value, 0, ".", ","));
    }

    function nl2br (str, is_xhtml) {
        if (typeof str === 'undefined' || str === null) {
            return '';
        }
        var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';
        return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1' + breakTag + '$2');
    }

    function f_addtemp(){
      let karyawans = document.getElementById('karyawans').value;
      let action = $("#action").val();

      if((karyawans != "kosong" && action == "Simpan") || action == "Edit"){
        let id_temp = $("#id_temp").val();

        if(action == "Simpan"){
          let akun = $("#akuns").val();

          $.post('/payroll/bulk-payroll/store-detil',{idpayroll: idpayroll, tanggalmulai: tanggalmulai, tanggalselesai: tanggalselesai, jenisgaji: jenisgaji, akun: akun, karyawan: karyawans, _token: '<?php echo e(csrf_token()); ?>'})
            .done(function(data){
              if(data != "gagal"){
                f_clear();
                toastr.success('Data ini berhasil disimpan.', 'Berhasil', { positionClass: 'toast-top-right', containerId: 'toast-top-right', "closeButton": true });
                f_loadtable();
                f_hitungtotal();
              }else{
                Swal.fire('Peringatan', 'Data gagal tersimpan!', 'error');
              }
            });
        }
        else if(action == "Edit"){
          let akundetil = $("#akundetil").val();
          let catatandetil = $("#catatandetil").val();
          let customabsen = accounting.unformat($("#customabsen").val() , ',');
          let customterlambat = accounting.unformat($("#customterlambat").val() , ',');

          let potabsendetil = accounting.unformat($("#potabsendetil").val() , ',');
          let potterlambatdetil = accounting.unformat($("#potterlambatdetil").val() , ',');
          let potpulangawaldetil = accounting.unformat($("#potpulangawaldetil").val() , ',');
          let potpinjamandetil = accounting.unformat($("#potpinjamandetil").val() , ',');
          let potijincutidetil = accounting.unformat($("#potijincutidetil").val() , ',');
          let potlainnyadetil = accounting.unformat($("#potlainnyadetil").val() , ',');

          let gajidetil = accounting.unformat($("#gajidetil").val() , ',');
          let lemburdetil = accounting.unformat($("#lemburdetil").val() , ',');
          let bonusdetil = accounting.unformat($("#bonusdetil").val() , ',');

          let potongandetil = accounting.unformat($("#potongandetil").val() , ',');
          let totalgaji = accounting.unformat($("#totalgaji").val() , ',');
          let gajibersih = accounting.unformat($("#gajibersih").val() , ',');

          $.post('/payroll/bulk-payroll/update-detil',{id_temp: id_temp, idpayroll: idpayroll, akundetil: akundetil, catatandetil: catatandetil, customabsen: customabsen, customterlambat: customterlambat, potabsendetil: potabsendetil, potterlambatdetil: potterlambatdetil, potpulangawaldetil: potpulangawaldetil, potpinjamandetil: potpinjamandetil, potijincutidetil: potijincutidetil, potlainnyadetil: potlainnyadetil, gajidetil: gajidetil, lemburdetil: lemburdetil, bonusdetil: bonusdetil, potongandetil: potongandetil, totalgaji: totalgaji, gajibersih: gajibersih, _token: '<?php echo e(csrf_token()); ?>'})
            .done(function(data){
              if(data == "berhasil"){
                f_clear();
                toastr.success('Data ini berhasil diedit.', 'Berhasil', { positionClass: 'toast-top-right', containerId: 'toast-top-right', "closeButton": true });
                $("#modal").modal('hide');
                f_loadtable();
                f_hitungtotal();
              }else{
                Swal.fire('Peringatan', 'Data gagal tersimpan!', 'error');
              }
            });
        }
      }else{
        Swal.fire('Peringatan', 'Pilih Karyawan terlebih dahulu!', 'error');
      }
    }

    function f_edittemp(param){
      let link = "/payroll/bulk-payroll/request-data-detil"; // Link untuk request data

      $.post(link, {id_temp: param, tanggalmulai: tanggalmulai, tanggalselesai: tanggalselesai, _token: '<?php echo e(csrf_token()); ?>'})
        .done(function (data) {
          let pecah = data.split("|");
          if (pecah[0] == "ada") {

            $('#id_temp').val(param);
            $("#namadetil").val(pecah[1]);
            $("#jabatandetil").val(pecah[2]);
            $("#akundetil").val(pecah[3]).trigger('change');
            $('#harikerjadetil').val(accounting.formatNumber(pecah[4], 0, ".", ","));
            $('#masukdetil').val(accounting.formatNumber(pecah[5], 0, ".", ","));
            $('#terlambatdetil').val(accounting.formatNumber(pecah[6], 0, ".", ","));
            $('#pulangawaldetil').val(accounting.formatNumber(pecah[7], 0, ".", ","));
            $('#absendetil').val(accounting.formatNumber(pecah[8], 0, ".", ","));
            $('#tamasukdetil').val(accounting.formatNumber(pecah[9], 0, ".", ","));
            $('#tapulangdetil').val(accounting.formatNumber(pecah[10], 0, ".", ","));
            $('#terlambatpulangawaldetil').val(accounting.formatNumber(pecah[11], 0, ".", ","));
            $('#ijindetil').val(accounting.formatNumber(pecah[12], 0, ".", ","));
            $('#cutidetil').val(accounting.formatNumber(pecah[13], 0, ".", ","));
            $('#potabsendetil').val(accounting.formatNumber(pecah[14], 0, ".", ","));
            $('#potterlambatdetil').val(accounting.formatNumber(pecah[15], 0, ".", ","));
            $('#potpulangawaldetil').val(accounting.formatNumber(pecah[16], 0, ".", ","));
            $('#potpinjamandetil').val(accounting.formatNumber(pecah[17], 0, ".", ","));
            $('#potijincutidetil').val(accounting.formatNumber(pecah[18], 0, ".", ","));
            $('#potlainnyadetil').val(accounting.formatNumber(pecah[19], 0, ".", ","));
            $('#lemburdetil').val(accounting.formatNumber(pecah[20], 0, ".", ","));
            $('#bonusdetil').val(accounting.formatNumber(pecah[21], 0, ".", ","));
            $('#sisapinjamandetil').val(accounting.formatNumber(pecah[22], 0, ".", ","));
            $('#pinjamanperiodelalu').val(accounting.formatNumber(pecah[23], 0, ".", ","));
            $('#pinjamanperiodesekarang').val(accounting.formatNumber(pecah[24], 0, ".", ","));
            $('#gajidetil').val(accounting.formatNumber(pecah[25], 0, ".", ","));
            $('#gajibersih').val(accounting.formatNumber(pecah[26], 0, ".", ","));
            $('#customabsen').val(accounting.formatNumber(pecah[27], 0, ".", ","));
            $('#customterlambat').val(accounting.formatNumber(pecah[28], 0, ".", ","));
            $("#catatandetil").val(pecah[29]);
            $("#action").val("Edit");

            f_hitunggaji();

            $("#modal").modal();
          }
        });
    }

    function f_customabsen(){
        let gaji = accounting.unformat($("#gajidetil").val() , ',');
        let harikerja = accounting.unformat($("#harikerjadetil").val() , ',');

        let customabsen = accounting.unformat($("#customabsen").val() , ',');

        let gajiperhari = gaji / harikerja;
        let potabsen = customabsen * gajiperhari;

        $('#potabsendetil').val(accounting.formatNumber(potabsen, 0, ".", ","));

        f_hitunggaji();
    }

    function f_hitunggaji(){
        let potabsendetil = accounting.unformat($("#potabsendetil").val() , ',');
        let potterlambatdetil = accounting.unformat($("#potterlambatdetil").val() , ',');
        let potpulangawaldetil = accounting.unformat($("#potpulangawaldetil").val() , ',');
        let potpinjamandetil = accounting.unformat($("#potpinjamandetil").val() , ',');
        let potijincutidetil = accounting.unformat($("#potijincutidetil").val() , ',');
        let potlainnyadetil = accounting.unformat($("#potlainnyadetil").val() , ',');

        let gajidetil = accounting.unformat($("#gajidetil").val() , ',');
        let lemburdetil = accounting.unformat($("#lemburdetil").val() , ',');
        let bonusdetil = accounting.unformat($("#bonusdetil").val() , ',');

        let sumpotongan = potabsendetil + potterlambatdetil + potpulangawaldetil + potpinjamandetil + potijincutidetil + potlainnyadetil;
        let sumgaji = gajidetil + lemburdetil + bonusdetil;
        let sumgajibersih = sumgaji - sumpotongan;

        $('#potongandetil').val(accounting.formatNumber(sumpotongan, 0, ".", ","));
        $('#totalgaji').val(accounting.formatNumber(sumgaji, 0, ".", ","));
        $('#gajibersih').val(accounting.formatNumber(sumgajibersih, 0, ".", ","));
    }

    function f_deletetemp(param){
      Swal.fire({
        title: 'Konfirmasi',
        text: "Apakah anda yakin untuk menghapus data ini?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya',
        cancelButtonText: 'Tidak',
        confirmButtonClass: 'btn btn-primary',
        cancelButtonClass: 'btn btn-danger ml-1',
        buttonsStyling: false,
      }).then(function (result) {
        if (result.value) {
          let link = "/payroll/bulk-payroll/drop-detil"; // Link untuk hapus

          $.post(link, {id: param, _token: '<?php echo e(csrf_token()); ?>'})
            .done(function (data) {
              if (data == "berhasil") {
                toastr.success('Data ini berhasil dihapus.', 'Berhasil', { positionClass: 'toast-top-right', containerId: 'toast-top-right', "closeButton": true });
                f_loadtable();
                f_hitungtotal();
              }else{
                Swal.fire('Peringatan', 'Data gagal tersimpan!', 'error');
              }
            });
        }
      })
    }

    function f_clear(){
      $("#karyawans").val("kosong").trigger('change');
      $("#action").val("Simpan");
      $("#karyawans").focus();
    }

    function f_hitungtotal(){
      $.post('/payroll/bulk-payroll/request-total-detil',{idpayroll: idpayroll, _token: '<?php echo e(csrf_token()); ?>'})
        .done(function(data){
          let pecah = data.split("|");
          if (pecah[0] == "ada") {
            $("#subtotal").val(accounting.formatMoney(pecah[1], "Rp ", 0, ".", ","));
            $("#totalpotongan").val(accounting.formatMoney(pecah[2], "Rp ", 0, ".", ","));
            $("#totalakhir").val(accounting.formatMoney(pecah[3], "Rp ", 0, ".", ","));
          }
        });
    }

    function f_prosesdata(param){
      f_loadtable();
      f_hitungtotal();

      let action = "Belum Selesai";

      if(param == "selesai"){
          action = "Selesai";
      }

      if(action == "Belum Selesai"){
          window.close();
      }

      let akun = $("#akuns").val();
      let subtotal = accounting.unformat($("#subtotal").val() , ',');
      let totalpotongan = accounting.unformat($("#totalpotongan").val() , ',');
      let totalakhir = accounting.unformat($("#totalakhir").val() , ',');

      $.post('/payroll/bulk-payroll/proses-detil',{idpayroll: idpayroll, akun: akun, subtotal: subtotal, totalpotongan: totalpotongan, totalakhir: totalakhir, action: action, _token: '<?php echo e(csrf_token()); ?>'})
        .done(function(data){
          if(data == "berhasil"){
            Swal.fire({
              title: 'Informasi',
              text: "Data berhasil tersimpan",
              type: 'info',
              confirmButtonText: 'Ya',
              confirmButtonClass: 'btn btn-primary',
              buttonsStyling: false,
            }).then(function (result) {
                location.href = "/payroll/bulk-payroll/";
            })
          }else{
            Swal.fire('Peringatan', 'Data gagal tersimpan!', 'error');
          }
        });
    }
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/MJA/resources/views/apps/payroll/bulk-payroll/view-detil.blade.php ENDPATH**/ ?>