<?php $__env->startSection('title', 'Data Pembelian Detil'); ?>
<?php $__env->startSection('page-title', 'Data Pembelian Detil'); ?>


<?php $__env->startSection('vendor-style'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/datatables.min.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/animate/animate.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/sweetalert2.min.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/pickadate/pickadate.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset(mix('css/pages/data-list-view.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('css/plugins/extensions/toastr.css'))); ?>">

  <style>

    .invalid-tooltip{
      right:0;
      margin-right: 15px;
    }

  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- card actions section start -->
  <section>
    <!-- Info table about action starts -->
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <h4 class="card-title">Data Dropshipper</h4>
            <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
            <div class="heading-elements">
              <ul class="list-inline mb-0">
                <li><a data-action="collapse"><i class="feather icon-chevron-down"></i></a></li>
              </ul>
            </div>
          </div>
          <div class="card-content collapse show">
            <div class="card-body">
              <div class="row">
                <div class="col-sm-12">

                  <div class="row mb-1">

                    <div class="col-sm-12 col-md-6 mb-1">

                      <div class="row">

                        <div class="col-sm-12 col-md-12 mb-1">
                          <label>Kode Dropshipper</label>
                          <input type="text" class="form-control" value="<?php echo e($dropshipper->kode); ?>" readonly>
                        </div>

                        <div class="col-sm-12 col-md-12 mb-1">
                          <label>Nama Penampung</label>
                          <input type="text" class="form-control" value="<?php echo e($dropshipper->namapenampung); ?>" readonly>
                        </div>

                        <div class="col-sm-12 col-md-12 mb-1">
                          <label>No. Kontainer</label>
                          <input type="text" class="form-control" value="<?php echo e($dropshipper->no_kontainer); ?>" readonly>
                        </div>

                      </div>


                    </div>

                    <div class="col-sm-12 col-md-6 mb-1" style="border: 2px solid black;border-radius:10px;padding-top:15px;padding-bottom:15px;">

                      <div class="row">

                        <div class="col-sm-12 col-md-6 mb-1">
                          <label>No. Segel</label>
                          <input type="text" class="form-control" value="<?php echo e($dropshipper->no_segel); ?>" readonly>
                        </div>

                        <div class="col-sm-12 col-md-6 mb-1">
                          <label>No. Nota</label>
                          <input type="text" class="form-control" value="<?php echo e($dropshipper->no_nota); ?>" readonly>
                        </div>

                        <div class="col-sm-12 col-md-12 mb-1">
                          <label>Keterangan</label>
                          <textarea class="form-control" name="keterangan" id="keterangan" readonly><?php echo e($dropshipper->keterangan); ?></textarea>
                        </div>

                      </div>

                    </div>

                    <div class="col-sm-12 col-md-12 mb-1">
                      <label for="akuns">Pilih Akun Pembayaran</label>
                      <select class="form-control select" name="akuns" id="akuns">
                        <?php $__currentLoopData = $akuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option data-foo="<?php echo e($akun->kategori); ?>" value="<?php echo e($akun->kode_akun); ?>"><?php echo e($akun->kode_akun); ?> - <?php echo e($akun->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>

                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Info table about action Ends -->
  </section>

  
  <section id="data-list-view" class="data-list-view-header card" style="padding:25px 15px;">

    <div class="col-md-12">
      <div class="row">

        <input type="hidden" name="id_temp" id="id_temp" />
        <input type="hidden" name="action" id="action" />

        <div class="col-sm-12 col-md-4 pl-1">
          <label for="nama">Nama Item</label>
          <input type="text" class="form-control" name="nama" id="nama">
        </div>

        <div class="col-sm-12 col-md-3 pl-0">
          <label for="tanggal">Tanggal</label>
          <input type="text" class="form-control date" name="tanggal" id="tanggal">
        </div>

        <div class="col-sm-12 col-md-3 pl-0">
          <label for="catatan">Catatan</label>
          <input type="text" class="form-control" name="catatan" id="catatan">
        </div>

        <div class="col-sm-12 col-md-2 pl-0">
          <label for="nominal">Biaya</label>
          <input type="text" class="form-control" name="nominal" id="nominal" value="0" onfocus="f_tonumber(this.id)" onblur="f_tocurrency(this.id);">
        </div>

      </div>

    </div>

    
    <div class="table-responsive">
      <table class="table data-list-view" style="border:none;">
        <thead>
        <tr>
          <th width="25px">No.</th>
          <th>Kode</th>
          <th>Nama Item</th>
          <th>Tanggal</th>
          <th>Biaya</th>
          <th>Catatan</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
        </thead>
      </table>
    </div>
    

    <div class="col-md-12 mt-1">

      <div class="row mr-1">

        <div class="col-md-6 mt-1 offset-3 col-sm-12 text-right"> <h4 style="margin:6px auto;"> Subtotal : </h4> </div>
        <div class="col-md-3 mt-1 col-sm-12">
          <input type="text" class="form-control" style="font-weight: bold;" name="subtotal" id="subtotal" value="Rp 0" readonly>
        </div>

        <div class="col-md-12 mt-1 col-sm-12 text-right">
          <button type="button" id="btnsimpan" name="btnsimpan" class="btn bg-gradient-success waves-effect waves-light" onclick="window.open('/jasa/dropshipper','_self')"> Tutup Data </button>
        </div>

      </div>

    </div>

  </section>
  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
  
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.bootstrap4.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/buttons.bootstrap.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/extensions/sweetalert2.all.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/extensions/toastr.min.js'))); ?>"></script>
  <script src="https://momentjs.com/downloads/moment-with-locales.min.js"></script>
  <script src="http://cdn.datatables.net/plug-ins/1.10.15/dataRender/datetime.js"></script>
  <script src="https://unpkg.com/accounting@0.4.1/accounting.js"></script>
  <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.date.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/legacy.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/forms/select/select2.full.min.js'))); ?>"></script>
  <script src="https://unpkg.com/accounting@0.4.1/accounting.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
  

  <script>

    let iddropshipper = "<?php echo e($dropshipper->id); ?>";

    $(document).ready(function() {

      "use strict"

      $("body").tooltip({ selector: '[data-toggle=tooltip]' });
        $('#biayatambahan').val(accounting.formatNumber(<?php echo e($dropshipper->biaya_tambahan); ?>, 0, ".", ","));

      // init list view datatable
      f_loadtable();
      f_hitungtotal();
      f_clear();

      $( '.date' ).pickadate({
        formatSubmit: 'yyyy-mm-dd',
        monthsFull: [ 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember' ],
        monthsShort: [ 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des' ],
        weekdaysShort: [ 'Mgg', 'Sn', 'Sl', 'Rb', 'Kms', 'Jum', 'Sab' ],
        today: 'Hari Ini',
        clear: 'Hapus Tanggal',
        close: 'Tutup',
        selectYears: true,
        selectMonths: true,
        firstDay: 1
      });

      $(".select").select2({
        dropdownAutoWidth: true,
        width: '100%',
        matcher: matchCustom,
        templateResult: formatCustom
      });

    });

    function stringMatch(term, candidate) {
      return candidate && candidate.toLowerCase().indexOf(term.toLowerCase()) >= 0;
    }

    function matchCustom(params, data) {
      // If there are no search terms, return all of the data
      if ($.trim(params.term) === '') {
        return data;
      }
      // Do not display the item if there is no 'text' property
      if (typeof data.text === 'undefined') {
        return null;
      }
      // Match text of option
      if (stringMatch(params.term, data.text)) {
        return data;
      }
      // Match attribute "data-foo" of option
      if (stringMatch(params.term, $(data.element).attr('data-foo'))) {
        return data;
      }
      // Return `null` if the term should not be displayed
      return null;
    }

    function formatCustom(state) {
      return $(
        '<div><div>' + state.text + '</div><div class="foo">'
        + $(state.element).attr('data-foo')
        + '</div></div>'
      );
    }

    function f_loadtable(){
      let dataListView = $(".data-list-view").DataTable({
        "destroy": true,
        processing: true,
        serverSide: true,
        ajax: "/jasa/dropshipper/detil-biaya/list-detil?id="+iddropshipper,
        columns: [
          {data: 'DT_RowIndex', name: 'DT_RowIndex', searchable: false},
          {data: 'kode', name: 'kode'},
          {data: 'nama', name: 'nama'},
          {data: 'tanggal', name: 'tanggal',render: function ( data, type, row, meta ) {
              if(data != null){
                  return moment(data).locale('id').format('DD MMMM YYYY');
              }else{
                  return '-';
              }
          }},
          {data: 'nominal', name: 'nominal', render: $.fn.dataTable.render.number( '.', ',', 2 )},
          {data: 'catatan', name: 'catatan'},
          {data: 'status', name: 'status',render: function ( data, type, row, meta ) {
              if(data == "Lunas"){
                  return '<span class="badge badge-pill bg-success">Lunas</span>';
              }else{
                  return '<span class="badge badge-pill bg-warning">Belum Lunas</span>';
              }
          }},
          {data: 'action', name: 'action', orderable: false, searchable: false}
        ],
        responsive: false,
        columnDefs: [
          {
            orderable: true,
          }
        ],
        dom:
          '<"top"<"actions action-btns"B><"action-filters"lf>><"clear">rt<"bottom"<"actions">p>',
        oLanguage: {
          sLengthMenu: "_MENU_",
          sSearch: ""
        },
        aLengthMenu: [[10, 20, 50, -1], [10, 20, 50, 'All']],
        order: [[0, "asc"]],
        bInfo: false,
        "paging": false,
        "bLengthChange": false,
        pageLength: -1,
        buttons: [
          {
            text: "<i class='feather icon-plus'></i> Simpan Data",
            action: function () {
              f_addtemp()
            },
            className: "btn bg-gradient-success waves-effect waves-light",
          }
        ],
        initComplete: function (settings, json) {
          $(".dt-buttons .btn").removeClass("btn-secondary")
        }
      });
    }

    function minmax(value, min, max)
    {
      if(parseInt(value) < min || isNaN(parseInt(value)))
        return min;
      else if(parseInt(value) > max)
        return max;
      else return value;
    }

    function f_tonumber(param){
      let value = $("#"+param).val();
      $("#"+param).val(accounting.unformat(value , ','));
    }

    function f_tocurrency(param){
      let value = $("#"+param).val();
      $("#"+param).val(accounting.formatNumber(value, 2, ".", ","));
    }

    function nl2br (str, is_xhtml) {
        if (typeof str === 'undefined' || str === null) {
            return '';
        }
        var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';
        return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1' + breakTag + '$2');
    }

    function f_addtemp(){
      let nama = document.getElementById('nama').value;
      let action = $("#action").val();
      let kodedropshipper = "<?php echo e($dropshipper->kode); ?>";

      if((nama != "" && action == "Simpan") || action == "Edit"){
        let id_temp = $("#id_temp").val();
        let catatan = $("#catatan").val();
        let nominal = accounting.unformat($("#nominal").val() , ',');
        let tanggal = $("[name=tanggal_submit]").val();

        if(action == "Simpan"){
          $.post('/jasa/dropshipper/detil-biaya/store-detil',{iddropshipper: iddropshipper, kodedropshipper: kodedropshipper, nama: nama, nominal: nominal, tanggal: tanggal, catatan: catatan, _token: '<?php echo e(csrf_token()); ?>'})
            .done(function(data){
                if(data != "gagal"){
                    f_clear();
                    toastr.success('Data ini berhasil disimpan.', 'Berhasil', { positionClass: 'toast-top-right', containerId: 'toast-top-right', "closeButton": true });
                    f_loadtable();
                    f_hitungtotal();
                }else{
                    Swal.fire('Peringatan', 'Data gagal tersimpan!', 'error');
                }
            });
        }
        else if(action == "Edit"){
            $.post('/jasa/dropshipper/detil-biaya/update-detil',{id_temp: id_temp, iddropshipper: iddropshipper, nama: nama, nominal: nominal, tanggal: tanggal, catatan: catatan, _token: '<?php echo e(csrf_token()); ?>'})
            .done(function(data){
                if(data != "gagal"){
                    f_clear();
                    toastr.success('Data ini berhasil disimpan.', 'Berhasil', { positionClass: 'toast-top-right', containerId: 'toast-top-right', "closeButton": true });
                    f_loadtable();
                    f_hitungtotal();
                }else{
                    Swal.fire('Peringatan', 'Data gagal tersimpan!', 'error');
                }
            });
        }
      }else{
        Swal.fire('Peringatan', 'Pilih Produk terlebih dahulu!', 'error');
      }
    }

    function f_edittemp(param){
      let link = "/jasa/dropshipper/detil-biaya/request-data-detil"; // Link untuk request data

      $.post(link, {id_temp: param, _token: '<?php echo e(csrf_token()); ?>'})
        .done(function (data) {
          let pecah = data.split("|");
          if (pecah[0] == "ada") {

            $('#id_temp').val(param);
            $("#nama").val(pecah[1]);
            $("#catatan").val(pecah[2]);
            $('#nominal').val(accounting.formatNumber(pecah[3], 2, ".", ","));
            if(pecah[4] != "") {
                const tanggal_js = new Date(pecah[4]);
                $("#tanggal").pickadate('picker').set('select', tanggal_js);
            }
            $("#action").val("Edit");

            $("#modal").modal();
          }
        });
    }

    function f_deletetemp(param){
      Swal.fire({
        title: 'Konfirmasi',
        text: "Apakah anda yakin untuk menghapus data ini?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya',
        cancelButtonText: 'Tidak',
        confirmButtonClass: 'btn btn-primary',
        cancelButtonClass: 'btn btn-danger ml-1',
        buttonsStyling: false,
      }).then(function (result) {
        if (result.value) {
          let link = "/jasa/dropshipper/detil-biaya/drop-detil"; // Link untuk hapus

          $.post(link, {id: param, _token: '<?php echo e(csrf_token()); ?>'})
            .done(function (data) {
              if (data == "berhasil") {
                toastr.success('Data ini berhasil dihapus.', 'Berhasil', { positionClass: 'toast-top-right', containerId: 'toast-top-right', "closeButton": true });
                f_loadtable();
                f_hitungtotal();
              }else{
                Swal.fire('Peringatan', 'Data gagal tersimpan!', 'error');
              }
            });
        }
      })
    }

    function f_bayar(param){
      Swal.fire({
        title: 'Konfirmasi',
        text: "Apakah anda yakin untuk melakukan pembayaran data ini?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya',
        cancelButtonText: 'Tidak',
        confirmButtonClass: 'btn btn-primary',
        cancelButtonClass: 'btn btn-danger ml-1',
        buttonsStyling: false,
      }).then(function (result) {
        if (result.value) {
          let link = "/jasa/dropshipper/detil-biaya/bayar"; // Link untuk hapus
          let akun = $("#akuns").val();


          $.post(link, {id: param, akun: akun, _token: '<?php echo e(csrf_token()); ?>'})
            .done(function (data) {
              if (data == "berhasil") {
                toastr.success('Data ini berhasil terbayar.', 'Berhasil', { positionClass: 'toast-top-right', containerId: 'toast-top-right', "closeButton": true });
                f_loadtable();
                f_hitungtotal();
              }else{
                Swal.fire('Peringatan', 'Data gagal tersimpan!', 'error');
              }
            });
        }
      })
    }

    function f_batalpelunasan(param){
      Swal.fire({
        title: 'Konfirmasi',
        text: "Apakah anda yakin untuk membatalkan pembayaran data ini?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya',
        cancelButtonText: 'Tidak',
        confirmButtonClass: 'btn btn-primary',
        cancelButtonClass: 'btn btn-danger ml-1',
        buttonsStyling: false,
      }).then(function (result) {
        if (result.value) {
          let link = "/jasa/dropshipper/detil-biaya/batalkanpelunasan"; // Link untuk hapus

          $.post(link, {id: param, _token: '<?php echo e(csrf_token()); ?>'})
            .done(function (data) {
              if (data == "berhasil") {
                toastr.success('Data ini berhasil dibatalkan.', 'Berhasil', { positionClass: 'toast-top-right', containerId: 'toast-top-right', "closeButton": true });
                f_loadtable();
                f_hitungtotal();
              }else{
                Swal.fire('Peringatan', 'Data gagal tersimpan!', 'error');
              }
            });
        }
      })
    }

    function f_clear(){
      $("#nominal").val(0);
      $("#catatan").val("");
      $("#action").val("Simpan");
      $("#nama").val("").focus();
    }

    function f_hitungtotal(){
      $.post('/jasa/dropshipper/detil-biaya/request-total-detil',{iddropshipper: iddropshipper, _token: '<?php echo e(csrf_token()); ?>'})
        .done(function(data){
          let pecah = data.split("|");
          if (pecah[0] == "ada") {
            let subtotal = parseInt(pecah[1]);

            $("#subtotal").val(accounting.formatMoney(subtotal, "Rp ", 2, ".", ","));
          }
        });
    }

  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/MJA/resources/views/apps/jasa/detil-biaya/index.blade.php ENDPATH**/ ?>