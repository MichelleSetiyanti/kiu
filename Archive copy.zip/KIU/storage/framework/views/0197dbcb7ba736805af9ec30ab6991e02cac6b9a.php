<?php $__env->startSection('title', 'Config Absensi Per Karyawan'); ?>
<?php $__env->startSection('page-title', 'Config Absensi Per Karyawan'); ?>


<?php $__env->startSection('vendor-style'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/datatables.min.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/animate/animate.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/sweetalert2.min.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/pickadate/pickadate.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/zebra_datepicker@latest/dist/css/bootstrap/zebra_datepicker.min.css">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset(mix('css/pages/data-list-view.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('css/plugins/extensions/toastr.css'))); ?>">

  <style>

    .invalid-tooltip{
      right:0;
      margin-right: 15px;
    }

    table.data-list-view.dataTable, table.data-thumb-view.dataTable{
      border-spacing: 0 !important;
      padding: 0.5rem 0.7rem !important;
    }

  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  <section id="data-list-view" class="data-list-view-header card" style="padding:25px 15px;">

    
    <div class="table-responsive">
      <table class="table data-list-view" style="border:none;width:100%">
        <thead>
        <tr>
          <th width="45px">No.</th>
          <th>Karyawan</th>
          <th>Waktu Masuk</th>
          <th>Waktu Pulang</th>
          <th>Start Waktu Masuk</th>
          <th>End Waktu Masuk</th>
          <th>Start Waktu Pulang</th>
          <th>End Waktu Pulang</th>
          <th>Action</th>
        </tr>
        </thead>
      </table>
    </div>
    

    
    <div class="add-new-data-sidebar">
      <div class="overlay-bg"></div>
      <div class="add-new-data">
        <form class="needs-validation" id="form" novalidate autocomplete="false">
          <div class="div mt-2 px-2 d-flex new-data-title justify-content-between">
            <div>
              <h4 class="text-uppercase proposal">Input Config Absensi</h4>
            </div>
            <div class="hide-data-sidebar">
              <i class="feather icon-x"></i>
            </div>
          </div>
          <div class="data-items pb-3" style="height:calc(100vh - 10rem)">
            <div class="data-fields px-2 mt-1">
              <div class="row">
                <input type="hidden" name="id" id="id" />
                <div class="col-sm-12 data-field-col">
                  <label for="karyawan">Karyawan</label>
                  <select class="form-control select" name="karyawan" id="karyawan" required>
                    <option value="" data-foo="" selected disabled> Pilih Karyawan </option>
                    <?php $__currentLoopData = $karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karyawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($karyawan->id); ?>" data-foo="Gaji : Rp <?php echo e(number_format($karyawan->gaji,0,',','.')); ?>"><?php echo e($karyawan->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <div class="invalid-tooltip">
                    Kolom ini harus diisi
                  </div>
                </div>
                <div class="col-sm-12 data-field-col">
                  <label for="waktumasuk">Waktu Masuk</label>
                  <input type="text" class="form-control" name="waktumasuk" id="waktumasuk">
                </div>

                <div class="col-sm-12 data-field-col">
                  <label for="waktupulang">Waktu Pulang</label>
                  <input type="text" class="form-control" name="waktupulang" id="waktupulang">
                </div>

                <div class="col-sm-12 data-field-col">
                  <label for="startwaktumasuk">Start Waktu Scan Masuk</label>
                  <input type="text" class="form-control" name="startwaktumasuk" id="startwaktumasuk">
                </div>

                <div class="col-sm-12 data-field-col">
                  <label for="endwaktumasuk">End Waktu Scan Masuk</label>
                  <input type="text" class="form-control" name="endwaktumasuk" id="endwaktumasuk">
                </div>

                <div class="col-sm-12 data-field-col">
                  <label for="startwaktupulang">Start Waktu Scan Pulang</label>
                  <input type="text" class="form-control" name="startwaktupulang" id="startwaktupulang">
                </div>

                <div class="col-sm-12 data-field-col">
                  <label for="endwaktupulang">End Waktu Scan Pulang</label>
                  <input type="text" class="form-control" name="endwaktupulang" id="endwaktupulang">
                </div>

              </div>
            </div>
          </div>
          <div class="add-data-footer d-flex justify-content-around px-3 mt-2">
            <div class="add-data-btn">
              <button type="button" class="btn btn-primary" value="Simpan" id="btnsubmit" name="btnsubmit" onclick="f_simpan(this.value)">Submit</button>
            </div>
            <div class="cancel-data-btn">
              <input type="button" class="btn btn-outline-danger" value="Cancel" onclick="f_clear()">
            </div>
          </div>
        </form>
      </div>
    </div>
    

  </section>
  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
  
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.bootstrap4.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/buttons.bootstrap.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/extensions/sweetalert2.all.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/extensions/toastr.min.js'))); ?>"></script>
  <script src="https://momentjs.com/downloads/moment-with-locales.min.js"></script>
  <script src="http://cdn.datatables.net/plug-ins/1.10.15/dataRender/datetime.js"></script>
  <script src="https://unpkg.com/accounting@0.4.1/accounting.js"></script>
  <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.date.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/legacy.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/forms/select/select2.full.min.js'))); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/zebra_datepicker@1.9.13/dist/zebra_datepicker.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
  

  <script>
    $(document).ready(function() {

      "use strict"

      $("body").tooltip({ selector: '[data-toggle=tooltip]' });

      // init list view datatable
      f_loadtable();
        
      $(".select").select2({
        dropdownAutoWidth: true,
        width: '100%',
        matcher: matchCustom,
        templateResult: formatCustom
      });

      $('#waktumasuk').mask('00:00:00');
      $('#waktupulang').mask('00:00:00');
      $('#startwaktumasuk').mask('00:00:00');
      $('#endwaktumasuk').mask('00:00:00');
      $('#startwaktupulang').mask('00:00:00');
      $('#endwaktupulang').mask('00:00:00');
        
      // Scrollbar
      if ($(".data-items").length > 0) {
        new PerfectScrollbar(".data-items", { wheelPropagation: false })
      }

      // Close sidebar
      $(".hide-data-sidebar, .cancel-data-btn, .overlay-bg").on("click", function() {
        f_clear();
      })

      f_loadtable();

      f_clear();

    });

    function stringMatch(term, candidate) {
      return candidate && candidate.toLowerCase().indexOf(term.toLowerCase()) >= 0;
    }

    function matchCustom(params, data) {
      // If there are no search terms, return all of the data
      if ($.trim(params.term) === '') {
        return data;
      }
      // Do not display the item if there is no 'text' property
      if (typeof data.text === 'undefined') {
        return null;
      }
      // Match text of option
      if (stringMatch(params.term, data.text)) {
        return data;
      }
      // Match attribute "data-foo" of option
      if (stringMatch(params.term, $(data.element).attr('data-foo'))) {
        return data;
      }
      // Return `null` if the term should not be displayed
      return null;
    }

    function formatCustom(state) {
      return $(
        '<div><div>' + state.text + '</div><div class="foo">'
        + $(state.element).attr('data-foo')
        + '</div></div>'
      );
    }

    function minmax(value, min, max)
    {
      if(parseInt(value) < min || isNaN(parseInt(value)))
        return min;
      else if(parseInt(value) > max)
        return max;
      else return value;
    }

    function f_tonumber(param){
      let value = $("#"+param).val();
      $("#"+param).val(accounting.unformat(value , ','));
    }

    function f_tocurrency(param){
      let value = $("#"+param).val();
      $("#"+param).val(accounting.formatNumber(value, 0, ".", ","));
    }

    function f_loadtable(){
      $("#tabel").removeClass('hidden');

      let dataListView = $(".data-list-view").DataTable({
        "destroy": true,
        processing: true,
        serverSide: true,
        ajax: "/config-absensi/perkaryawan/list",
        columns: [
          {data: 'DT_RowIndex', name: 'DT_RowIndex', searchable: false},
          {data: 'namakaryawan', name: 'namakaryawan'},
          {data: 'waktu_masuk', name: 'waktu_masuk'},
          {data: 'waktu_pulang', name: 'waktu_pulang'},
          {data: 'start_waktu_masuk', name: 'start_waktu_masuk'},
          {data: 'end_waktu_masuk', name: 'end_waktu_masuk'},
          {data: 'start_waktu_pulang', name: 'start_waktu_pulang'},
          {data: 'end_waktu_pulang', name: 'end_waktu_pulang'},
          {data: 'action', name: 'action', orderable: false, searchable: false}
        ],
        responsive: false,
        columnDefs: [
          {
            orderable: true,
          }
        ],
        dom:
          '<"top"<"actions action-btns"B><"action-filters"lf>><"clear">rt<"bottom"<"actions">p>',
        oLanguage: {
          sLengthMenu: "_MENU_",
          sSearch: ""
        },
        aLengthMenu: [[10, 20, 50, -1], [10, 20, 50, 'All']],
        order: [[0, "asc"]],
        bInfo: false,
        pageLength: 10,
        buttons: [
          {
            text: "<i class='feather icon-plus'></i> Tambah Data",
            action: function () {
              $(this).removeClass("btn-secondary")
              f_clear()
              $(".add-new-data").addClass("show")
              $(".overlay-bg").addClass("show")
            },
            className: "btn-outline-primary"
          }
        ],
        initComplete: function (settings, json) {
          $(".dt-buttons .btn").removeClass("btn-secondary")
        }
      });
    }

    function f_clear(){
      $(".add-new-data").removeClass("show");
      $(".overlay-bg").removeClass("show");
      $("#form").removeClass('was-validated');
      $("#id").val("");
      $("#karyawan").val("").prop('disabled',false).trigger('change');

      let link = "/config-absensi/global/request-data"; // Link untuk request data

      $.post(link, {id: '1', _token: '<?php echo e(csrf_token()); ?>'})
          .done(function (data) {
              let pecah = data.split("|");
              if (pecah[0] == "ada") {
                  $("#waktumasuk").val(pecah[1]);
                  $("#waktupulang").val(pecah[2]);
                  $("#startwaktumasuk").val(pecah[3]);
                  $("#endwaktumasuk").val(pecah[4]);
                  $("#startwaktupulang").val(pecah[5]);
                  $("#endwaktupulang").val(pecah[6]);
              }
          });

      $("#btnsubmit").val("Simpan");
    }

    function f_simpan(param){
      $("#form").addClass('was-validated');

      //cek kalau ada field required yang masih kosong
      let empty = false;
      $('#form').find('select, textarea, input').each(function(){
        if($( this ).prop( 'required' )){ if ( ! $( this ).val() ) { empty = true; } }
      });

      //tuliskan coding didalam if kalau udh ga ada field required yg kosong
      if (empty == false) {
        let link = "/config-absensi/perkaryawan/store"; // Link default untuk simpan
        let data = $("#form").serialize();

        let waktumasuk = $("#waktumasuk").val();
        let waktupulang = $("#waktupulang").val();
        let startwaktumasuk = $("#startwaktumasuk").val();
        let endwaktumasuk = $("#endwaktumasuk").val();
        let startwaktupulang = $("#startwaktupulang").val();
        let endwaktupulang = $("#endwaktupulang").val();

        if(waktumasuk.length != 8 || waktupulang.length != 8 || startwaktumasuk.length != 8 || endwaktumasuk.length != 8 || startwaktupulang.length != 8 || endwaktupulang.length != 8){
            toastr.error('Periksa kembali inputan waktu Anda.', 'Gagal', { positionClass: 'toast-top-right', containerId: 'toast-top-right', "closeButton": true });

            return;
        }

        if(param == "Edit"){
          link = "/config-absensi/perkaryawan/update"; // Ubah link untuk update
        }

        $.post(link,{data: data, waktumasuk: waktumasuk, waktupulang: waktupulang, startwaktumasuk: startwaktumasuk, endwaktumasuk: endwaktumasuk, startwaktupulang: startwaktupulang, endwaktupulang: endwaktupulang, _token: '<?php echo e(csrf_token()); ?>'})
          .done(function(data){
            f_clear();
            toastr.success('Pinjaman berhasil terinput.', 'Berhasil', { positionClass: 'toast-top-right', containerId: 'toast-top-right', "closeButton": true });
            f_loadtable();
          });
      }

    }

    function f_edit(param){
      let link = "/config-absensi/perkaryawan/request-data"; // Link untuk request data

      $.post(link, {id: param, _token: '<?php echo e(csrf_token()); ?>'})
        .done(function (data) {
          let pecah = data.split("|");
          if (pecah[0] == "ada") {
            $('#id').val(param);
            $("#waktumasuk").val(pecah[1]);
            $("#waktupulang").val(pecah[2]);
            $("#startwaktumasuk").val(pecah[3]);
            $("#endwaktumasuk").val(pecah[4]);
            $("#startwaktupulang").val(pecah[5]);
            $("#endwaktupulang").val(pecah[6]);
            $('#karyawan').val(pecah[7]).prop('disabled',true).trigger('change');

            $("#btnsubmit").val("Edit");
            $(".add-new-data").addClass("show");
            $(".overlay-bg").addClass("show");
          }
        });
    }

    function f_delete(param){
      Swal.fire({
        title: 'Konfirmasi',
        text: "Apakah anda yakin untuk menghapus data ini?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya',
        cancelButtonText: 'Tidak',
        confirmButtonClass: 'btn btn-primary',
        cancelButtonClass: 'btn btn-danger ml-1',
        buttonsStyling: false,
      }).then(function (result) {
        if (result.value) {
          let link = "/config-absensi/perkaryawan/drop"; // Link untuk hapus

          $.post(link, {id: param, _token: '<?php echo e(csrf_token()); ?>'})
            .done(function (data) {
              if (data == "berhasil") {
                toastr.success('Data ini berhasil dihapus.', 'Berhasil', { positionClass: 'toast-top-right', containerId: 'toast-top-right', "closeButton": true });
                f_loadtable();
              }
            });
        }
      })

    }

  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/MJA/resources/views/apps/config-absensi/perkaryawan/index.blade.php ENDPATH**/ ?>